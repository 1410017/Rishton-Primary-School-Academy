<?php include '../inc/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Parent</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
    <div class="container">
        <h2>Edit Parent</h2>
        <?php
        if (isset($_GET['id'])) {
            $parent_id = $_GET['id'];
            $sql = "SELECT * FROM parent WHERE parent_id = $parent_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
            } else {
                echo "<div class='alert alert-danger'>No parent found with this ID</div>";
            }
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $parent_id = $_POST['parent_id'];
            $first_name = $_POST['first_name'];
            $last_name = $_POST['last_name'];
            $phone_number = $_POST['phone_number'];

            $sql = "UPDATE parent SET first_name='$first_name', last_name='$last_name', phone_number='$phone_number' WHERE parent_id=$parent_id";

            if ($conn->query($sql) === TRUE) {
                echo "<div class='alert alert-success'>Parent updated successfully</div>";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
        ?>

        <form action="update.php?id=<?php echo $parent_id; ?>" method="post">
            <input type="hidden" name="parent_id" value="<?php echo $row['parent_id']; ?>">
            <div class="form-group">
                <label for="first_name">First Name:</label>
                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $row['first_name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="last_name">Last Name:</label>
                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $row['last_name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="phone_number">Phone Number:</label>
                <input type="text" class="form-control" id="phone_number" name="phone_number" value="<?php echo $row['phone_number']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Parent</button>
        </form>
        <a href="index.php" class="btn btn-secondary">Back to Parent List</a>
    </div>
</body>
</html>



<?php include '../inc/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Parent</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
    <div class="container">
        <h2>View Parent</h2>
        <?php
        if (isset($_GET['id'])) {
            $parent_id = $_GET['id'];
            $sql = "SELECT * FROM parent WHERE parent_id = $parent_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo "<p><strong>ID:</strong> {$row['parent_id']}</p>";
                echo "<p><strong>First Name:</strong> {$row['first_name']}</p>";
                echo "<p><strong>Last Name:</strong> {$row['last_name']}</p>";
                echo "<p><strong>Phone Number:</strong> {$row['phone_number']}</p>";
            } else {
                echo "<div class='alert alert-danger'>No parent found with this ID</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>Invalid ID</div>";
        }
        ?>
        <a href="index.php" class="btn btn-primary">Back to Parent List</a>
    </div>
</body>
</html>

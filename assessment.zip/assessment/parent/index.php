<?php include '../inc/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Parent List</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
    <div class="container">
        <h2>Parents</h2>
        <a href="create.php" class="btn btn-primary mb-2">Add New Parent</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Phone Number</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM parent";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['parent_id']}</td>
                                <td>{$row['first_name']}</td>
                                <td>{$row['last_name']}</td>
                                <td>{$row['phone_number']}</td>
                                <td>
                                    <a href='read.php?id={$row['parent_id']}'>View</a> |
                                    <a href='update.php?id={$row['parent_id']}'>Edit</a> |
                                    <a href='delete.php?id={$row['parent_id']}'>Delete</a>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>No parents found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

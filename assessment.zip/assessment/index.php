<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rishton Academy Primary School</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include './inc/navbar.php'; ?>
    <div class="container">
        <h2>Rishton Academy Primary School</h2>
        <div class="list-group">
            <a href="student/index.php" class="list-group-item list-group-item-action">Manage Students</a>
            <a href="parent/index.php" class="list-group-item list-group-item-action">Manage Parents</a>
            <a href="teacher/index.php" class="list-group-item list-group-item-action">Manage Teachers</a>
        </div>
    </div>
</body>
</html>

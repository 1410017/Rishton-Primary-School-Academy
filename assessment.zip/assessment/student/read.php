<?php include '../inc/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Student</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
    <div class="container">
        <h2>View Student</h2>
        <?php
        if (isset($_GET['id'])) {
            $student_id = $_GET['id'];
            $sql = "SELECT student.student_id, student.first_name, student.last_name, class.class_name, parent.first_name AS parent_first_name, parent.last_name AS parent_last_name FROM student 
                    JOIN class ON student.class_id = class.class_id 
                    JOIN parent ON student.parent_id = parent.parent_id
                    WHERE student.student_id = $student_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo "<p><strong>ID:</strong> {$row['student_id']}</p>";
                echo "<p><strong>First Name:</strong> {$row['first_name']}</p>";
                echo "<p><strong>Last Name:</strong> {$row['last_name']}</p>";
                echo "<p><strong>Class:</strong> {$row['class_name']}</p>";
                echo "<p><strong>Parent:</strong> {$row['parent_first_name']} {$row['parent_last_name']}</p>";
            } else {
                echo "<div class='alert alert-danger'>No student found with this ID</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>Invalid ID</div>";
        }
        ?>
        <a href="index.php" class="btn btn-primary">Back to Student List</a>
    </div>
</body>
</html>

<?php include '../inc/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Student</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
    <div class="container">
        <h2>Add New Student</h2>
        <form action="create.php" method="post">
            <div class="form-group">
                <label for="first_name">First Name:</label>
                <input type="text" class="form-control" id="first_name" name="first_name" required>
            </div>
            <div class="form-group">
                <label for="last_name">Last Name:</label>
                <input type="text" class="form-control" id="last_name" name="last_name" required>
            </div>
            <div class="form-group">
                <label for="class_id">Class:</label>
                <select class="form-control" id="class_id" name="class_id" required>
                    <?php
                    $sql = "SELECT * FROM class";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<option value='{$row['class_id']}'>{$row['class_name']}</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="parent_id">Parent:</label>
                <select class="form-control" id="parent_id" name="parent_id" required>
                    <?php
                    $sql = "SELECT * FROM parent";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<option value='{$row['parent_id']}'>{$row['first_name']} {$row['last_name']}</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Add Student</button>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $first_name = $_POST['first_name'];
            $last_name = $_POST['last_name'];
            $class_id = $_POST['class_id'];
            $parent_id = $_POST['parent_id'];

            $sql = "INSERT INTO student (first_name, last_name, class_id, parent_id) VALUES ('$first_name', '$last_name', '$class_id', '$parent_id')";

            if ($conn->query($sql) === TRUE) {
                echo "<div class='alert alert-success'>New student created successfully</div>";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
        ?>
    </div>
</body>
</html>

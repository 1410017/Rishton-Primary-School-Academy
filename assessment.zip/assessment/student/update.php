<?php include '../inc/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Student</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
    <div class="container">
        <h2>Edit Student</h2>
        <?php
        if (isset($_GET['id'])) {
            $student_id = $_GET['id'];
            $sql = "SELECT * FROM student WHERE student_id = $student_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
            } else {
                echo "<div class='alert alert-danger'>No student found with this ID</div>";
            }
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $student_id = $_POST['student_id'];
            $first_name = $_POST['first_name'];
            $last_name = $_POST['last_name'];
            $class_id = $_POST['class_id'];
            $parent_id = $_POST['parent_id'];

            $sql = "UPDATE student SET first_name='$first_name', last_name='$last_name', class_id='$class_id', parent_id='$parent_id' WHERE student_id=$student_id";

            if ($conn->query($sql) === TRUE) {
                echo "<div class='alert alert-success'>Student updated successfully</div>";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
        ?>

        <form action="update.php?id=<?php echo $student_id; ?>" method="post">
            <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
            <div class="form-group">
                <label for="first_name">First Name:</label>
                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $row['first_name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="last_name">Last Name:</label>
                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $row['last_name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="class_id">Class:</label>
                <select class="form-control" id="class_id" name="class_id" required>
                    <?php
                    $sql = "SELECT * FROM class";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while($class_row = $result->fetch_assoc()) {
                            $selected = ($class_row['class_id'] == $row['class_id']) ? "selected" : "";
                            echo "<option value='{$class_row['class_id']}' $selected>{$class_row['class_name']}</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="parent_id">Parent:</label>
                <select class="form-control" id="parent_id" name="parent_id" required>
                    <?php
                    $sql = "SELECT * FROM parent";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while($parent_row = $result->fetch_assoc()) {
                            $selected = ($parent_row['parent_id'] == $row['parent_id']) ? "selected" : "";
                            echo "<option value='{$parent_row['parent_id']}' $selected>{$parent_row['first_name']} {$parent_row['last_name']}</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update Student</button>
        </form>
        <a href="index.php" class="btn btn-secondary">Back to Student List</a>
    </div>
</body>
</html>

<?php include '../inc/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Teacher</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
    <div class="container">
        <h2>Edit Teacher</h2>
        <?php
        if (isset($_GET['id'])) {
            $teacher_id = $_GET['id'];
            $sql = "SELECT * FROM teacher WHERE teacher_id = $teacher_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
            } else {
                echo "<div class='alert alert-danger'>No teacher found with this ID</div>";
            }
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $teacher_id = $_POST['teacher_id'];
            $first_name = $_POST['first_name'];
            $last_name = $_POST['last_name'];

            $sql = "UPDATE teacher SET first_name='$first_name', last_name='$last_name' WHERE teacher_id=$teacher_id";

            if ($conn->query($sql) === TRUE) {
                echo "<div class='alert alert-success'>Teacher updated successfully</div>";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
        ?>

        <form action="update.php?id=<?php echo $teacher_id; ?>" method="post">
            <input type="hidden" name="teacher_id" value="<?php echo $row['teacher_id']; ?>">
            <div class="form-group">
                <label for="first_name">First Name:</label>
                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $row['first_name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="last_name">Last Name:</label>
                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $row['last_name']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Teacher</button>
        </form>
        <a href="index.php" class="btn btn-secondary">Back to Teacher List</a>
    </div>
</body>
</html>

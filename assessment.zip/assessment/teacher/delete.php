<?php include '../inc/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Teacher</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
    <div class="container">
        <h2>Delete Teacher</h2>
        <?php
        if (isset($_GET['id'])) {
            $teacher_id = $_GET['id'];
            $sql = "DELETE FROM teacher WHERE teacher_id = $teacher_id";

            if ($conn->query($sql) === TRUE) {
                echo "<div class='alert alert-success'>Teacher deleted successfully</div>";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "<div class='alert alert-danger'>Invalid ID</div>";
        }
        ?>
        <a href="index.php" class="btn btn-primary">Back to Teacher List</a>
    </div>
</body>
</html>

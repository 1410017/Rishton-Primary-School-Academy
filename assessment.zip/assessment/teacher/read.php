<?php include '../inc/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Teacher</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
    <div class="container">
        <h2>View Teacher</h2>
        <?php
        if (isset($_GET['id'])) {
            $teacher_id = $_GET['id'];
            $sql = "SELECT * FROM teacher WHERE teacher_id = $teacher_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo "<p><strong>ID:</strong> {$row['teacher_id']}</p>";
                echo "<p><strong>First Name:</strong> {$row['first_name']}</p>";
                echo "<p><strong>Last Name:</strong> {$row['last_name']}</p>";
            } else {
                echo "<div class='alert alert-danger'>No teacher found with this ID</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>Invalid ID</div>";
        }
        ?>
        <a href="index.php" class="btn btn-primary">Back to Teacher List</a>
    </div>
</body>
</html>

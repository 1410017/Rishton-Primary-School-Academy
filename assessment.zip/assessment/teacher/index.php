<?php include '../inc/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher List</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include '../inc/navbar.php'; ?>
    <div class="container">
        <h2>Teachers</h2>
        <a href="create.php" class="btn btn-primary mb-2">Add New Teacher</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM teacher";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['teacher_id']}</td>
                                <td>{$row['first_name']}</td>
                                <td>{$row['last_name']}</td>
                                <td>
                                    <a href='read.php?id={$row['teacher_id']}'>View</a> |
                                    <a href='update.php?id={$row['teacher_id']}'>Edit</a> |
                                    <a href='delete.php?id={$row['teacher_id']}'>Delete</a>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4' class='text-center'>No teachers found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
